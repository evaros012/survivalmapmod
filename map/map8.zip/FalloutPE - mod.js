//FalloutPE Mod by NEGI
// For Adventure Map "FalloutPE"
//Don't Steal!


ModPE.setItem(1000,"book_written",0,"§7Diary of a Hermit",1);
ModPE.setItem(1001,"book_enchanted",0,"§cLogbook",1);
ModPE.setItem(1002,"nukekola",0,"§eNukeKola",16);
ModPE.setItem(1003,"pills",0,"§3Pills",16);
ModPE.setItem(1004,"armyknife",0,"§oArmy Knife",1);




 ModPE.setItem(2001,"plasmagun",0,"Plasma Gun"); 
ModPE.setItem(2000,"plasmaenergy",0,"Plasma Energy",16); 
 Item.setMaxDamage(409,2001) 
Item.setMaxDamage(100,1004) 

Block.defineBlock(200,'black_box',[['coal_block',0]],0,false,0);
Block.setRenderLayer(200,3);
Block.setLightOpacity(200,0);
 Block.setShape(200, 0.1, 0.0, 0.1, 0.9, 0.6, 0.9);
Block.defineBlock(210,'nuke_kola_box',[['nuke',0],['nuke',1],['nuke',0],['nuke',0],['nuke',0],['nuke',0]],0,false,0);
Block.setRenderLayer(210,3);
Block.setLightOpacity(210,0);
Block.setShape(210, 0.0, 0.0, 0.0, 1.0, 0.6, 1.0);
 
Block.setDestroyTime(200,99999);
Block.setDestroyTime(210,99999);

Block.defineBlock(211,'teleport_block',[['tp',0]],0,false,0);
Block.setDestroyTime(211,99999);


function newLevel()
{
Player.addItemCreativeInv(1000,1);
Player.addItemCreativeInv(1001,1);
Player.addItemCreativeInv(1002,1);
Player.addItemCreativeInv(1003,1);
oboyma = ModPE.readData("oboyma");
 Player.addItemCreativeInv(2000,1,0) 
Player.addItemCreativeInv(2001,1,0) 
Item.setHandEquipped(2001,true);
Player.addItemCreativeInv(1004,1,0) 
Item.setHandEquipped(1004,true);
}

var mis = false;
var tick =0;
var radiation = true;
var xx = Player.getX()
var yy = Player.getY()
var zz = Player.getZ()
 
var gui = true; 
var arrow; 
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(); 
var GUI; 
var oboyma = 16; 
var part = ParticleType.smoke; 


function toolUse(maxDamage,id) { 
  var pcid=Player.getCarriedItemData(); 
  if(pcid!==maxDamage){ 
    Entity.setCarriedItem(getPlayerEnt(),id,1,pcid+1); 
  } 
  if(pcid==maxDamage){ 
    Level.playSound(Player.getX(),Player.getY(),Player.getZ(),"random.break",2); 
    Entity.setCarriedItem(getPlayerEnt(),0,0,0); 
  } 
} 


function attackHook(a,v)
{
if(Player.getCarriedItem()==1004)
{

    var hit = Entity.getHealth(v)-6;
    Entity.setHealth(v,hit);
}
}


function useItem(x,y,z,i,b)
{
if(i==1000)
{
clientMessage('§8DAY 28');
clientMessage(' ');
clientMessage('§7I cant stand anymore. The wound is very sore and it burns. I hope what these pills will help me. This creatures everywhere find me. I dont know, how I many hold on...')
mis=true;
Player.addItemInventory(1000,-1);
}
if(i==1001)
{
clientMessage('§fRecord logbook passenger aircraft Boeing 747.');
clientMessage(' ');
clientMessage('§7 18 hours 47 minutes. December 11, 2288. Unusual activity was seen in the north-west about 4 kilometers from the aircraft. Increased seismic activity. Exceeding standards in radiation levels');
 
Player.addItemInventory(1001,-1);
}
if(b==200)
{
Level.dropItem(x+0.5,y-0.1,z+0.5,1,1001,1,1);
setTile(x,y,z,0);
clientMessage('§aQuest Completed');
clientMessage('Take your award');
Player.addItemInventory(294,1);
Player.addItemInventory(319,1);
}
if(b==210)
{
setTile(x,y,z,0);
Level.dropItem(x+0.5,y+0.1,z,1,1002,9,1);
clientMessage('§6NukeKola box');
}
if(i==1003)
{
Player.setHealth(Entity.getHealth(getPlayerEnt())+8);
Player.addItemInventory(1003,-1);
}
if(i==1002)
{
Player.setHealth(Entity.getHealth(getPlayerEnt())+2);
Entity.addEffect(getPlayerEnt(), 6,15*20, 0, true, false);
Entity.addEffect(getPlayerEnt(), 11,15*20, 0, true, false);
Player.addItemInventory(1002,-1);
}
if(b==69&&getTile(x,y-1,z)==99)
{
setTile(x,y-1,z,0);
setTile(x+1,y-1,z,0);
setTile(x-1,y-1,z,0);
setTile(x,y-1,z+1,0);
setTile(x,y-1,z-1,0);
setTile(x+1,y-1,z+1,0);
setTile(x-1,y-1,z-1,0);
setTile(x+1,y-1,z-1,0);
setTile(x-1,y-1,z+1,0);


setTile(x+2,y-1,z,0);
setTile(x-2,y-1,z,0);
setTile(x,y-1,z+2,0);
setTile(x,y-1,z-2,0);
setTile(x+2,y-1,z+2,0);
setTile(x-2,y-1,z-2,0);
setTile(x+2,y-1,z-2,0);
setTile(x-2,y-1,z+2,0);

setTile(x+3,y-1,z,0);
setTile(x-3,y-1,z,0);
setTile(x,y-1,z+3,0);
setTile(x,y-1,z-3,0);
setTile(x+3,y-1,z+3,0);
setTile(x-3,y-1,z-3,0);
setTile(x+3,y-1,z-3,0);
setTile(x-3,y-1,z+3,0);

explode(Player.getX(),Player.getY()-3,Player.getZ(),3.0);

clientMessage(Player.getName(getPlayerEnt()) + ":  Oh no! It's a trap!");
clientMessage('§aNew Mission: §o§eFind a Teleporter Core');
}
if(i==2000 && oboyma==0){ 
    Player.addItemInventory(2000,-1); 
    oboyma = 16; 
    Level.playSound(x+0.5,y+1,z+0.5, "random.click", 100, 30); 
    clientMessage(ChatColor.GOLD+"Cooldown completed!");
}
if(b==211)
{
setPosition(getPlayerEnt(),-227,63,142);
clientMessage(Player.getName(getPlayerEnt()) + ":  Where I am? ");
}
}

function procCmd(cmd)
{
if(cmd=='kit')
{
Player.addItemInventory(1000,1)
Player.addItemInventory(1001,1)
Player.addItemInventory(1002,64)
Player.addItemInventory(1003,64)

Player.addItemInventory(2000,16)
Player.addItemInventory(2001,1)
Player.addItemInventory(1004,1)
}
if(cmd=='box')
{
setTile(Player.getX(),Player.getY()-1,Player.getZ(),200);
}
if(cmd=='nuke')
{
setTile(Player.getX(),Player.getY()-1,Player.getZ(),211);
}

}

function modTick()
{
if(mis==true)
{
tick+=1;
}
if(tick>80)
{
clientMessage('§aQuest Completed');
clientMessage('Take your award');
Player.addItemInventory(355,1);
Player.addItemInventory(366,2);
mis=false;
tick=0;
}
if(Level.getBrightness(Player.getX(),Player.getY(),Player.getZ())==15&&radiation==true)
{
ModPE.showTipMessage('§cRadiation!');
Entity.addEffect(getPlayerEnt(), 2, 10, 0, true, false);
}
if(Player.getArmorSlot(0)==302)
{
radiation = false;
Entity.addEffect(getPlayerEnt(), 1, 10, 1, true, false);
}
if(Player.getArmorSlot(1)==303)
{
radiation = false;
Entity.addEffect(getPlayerEnt(), 11, 10, 0, true, false);
}
if(Player.getArmorSlot(2)==304)
{
radiation = false;
Entity.addEffect(getPlayerEnt(), 5, 10, 0, true, false);
}
if(Player.getArmorSlot(3)==305)
{
radiation = false;
Entity.addEffect(getPlayerEnt(), 8, 10, 2, true, false);
}
if(Player.getArmorSlot(0)==!302)
{
radiation = true;
}
if(getCarriedItem()==2001 && gui==true&&oboyma>=1)
{ 
openPR();
    ctx.runOnUiThread(new java.lang.Runnable(){ 
    run: function(){ 
    try{ 

    GUI = new android.widget.PopupWindow(); 
    var layout = new android.widget.LinearLayout(ctx); 
    layout.setOrientation(android.widget.LinearLayout.HORIZONTAL); 
    GUI.setContentView(layout); 
    var btn = new android.widget.Button(ctx); 
    var button = new android.widget.Button(ctx); 
    layout.addView(btn); 
    button.setText("Fire"); 
    GUI.setWidth(60); 
    GUI.setHeight(60); 
    GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.GREEN)); 
    btn.setOnClickListener(new android.view.View.OnClickListener({ 
    
    onClick: function(viewarg){ 
      ModPE.showTipMessage("+"); 
      var p=((Entity.getPitch(getPlayerEnt())+90)*Math.PI)/180; 
      var y=((Entity.getYaw(getPlayerEnt())+90)*Math.PI)/180; 
      var xx=Math.sin(p)*Math.cos(y); 
      var yy=Math.sin(p)*Math.sin(y); 
      var zz=Math.cos(p); 
      arrow = Level.spawnMob(Player.getX()+xx,Player.getY()+zz,Player.getZ()+yy ,80); 
      setVelX(arrow,8*xx); 
      setVelY(arrow,8*zz); 
      setVelZ(arrow,8*yy); 
      Level.playSoundEnt(arrow, "random.explode", 100, 100); 
      Entity.setFireTicks(arrow, 100); 
      ModPE.showTipMessage("§ePatrons-"+oboyma); 
      var xw = Entity.getX(arrow); 
      var yw = Entity.getY(arrow); 
      var zw = Entity.getZ(arrow); 
      part = ParticleType.crit; 
      Level.addParticle(part.toString(),xw,yw,zw,0,0,0,2.5); 
      Level.addParticle(part.toString(),getPlayerX(),getPlayerY(),getPlayerZ()-1,0,0,0,2.5);
      Level.addParticle(part.toString(),getPlayerX(),getPlayerY(),getPlayerZ()-1,0,0,0,2.6);
      oboyma-=1; 
      toolUse(409,2001); 
    } 
  })); 
  GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.BOTTOM | android.view.Gravity.RIGHT, 0, 160); 
  } catch (e){ 
print ("Error: "+e) 
} 
}}); 
gui=false;
} 
if(oboyma<1&&getCarriedItem ()==2001){ 
  ModPE.showTipMessage ("Oh, no! I need ammo!"); 
  ctx.runOnUiThread(new java.lang.Runnable({ 
  run: function(){ 
  if(GUI != null){ 
    GUI.dismiss(); 
    GUI = null; 
    GUIPR.dismiss();
    GUIPR = null;
  } 
}})); 
gui=true; 
} 
if(getCarriedItem()!=2001 && gui==false)
{ 
closePR();
  ctx.runOnUiThread(new java.lang.Runnable({ 
  run: function(){ 
  if(GUI != null){ 
    GUI.dismiss(); 
    GUI = null; 
    GUIPR.dismiss();
    GUIPR = null;
  } 
}})); 
gui=true;
} 
} 

function leaveGame(){ 
  ctx.runOnUiThread(new java.lang.Runnable({ 
  run: function(){ 
  if(GUI != null){ 
    GUI.dismiss(); 
    GUI = null; 
    GUIPR.dismiss();
    GUIPR = null;
  }}})); 
 ModPE.saveData("oboyma", oboyma); 
}

function openPR()
{
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var layout = new android.widget.LinearLayout(ctx);
      layout.setOrientation(1);
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(23);
      textview.setText('•');
      textview.setGravity(android.view.Gravity.CENTER);
      layout.addView(textview);
      
      GUIPR = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
      GUIPR.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      GUIPR.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.CENTER, 0, 0);
      }catch(err){
      print('An error occured: ' + err);
      }
      }}));
      }

       function closePR(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      if(GUIPR != null){
      GUIPR.dismiss();
      GUIPR = null;
      GUI.dismiss();
      GUI = null;
      }
      }}));
      }
